// Serves the Gridiron Call Sheet game AND the matchmaking (PeerJS) server on ONE port.
// Run: PORT=3100 node server.js     (default port 3100)
const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { ExpressPeerServer } = require('peer');

const PORT = +process.env.PORT || 3100;
const BASE = (process.env.BASE_PATH || '').replace(/\/$/, '');   // e.g. /football if mounted under a sub-path
const app = express();
const server = http.createServer(app);

const html = fs.readFileSync(path.join(__dirname, 'game.html'), 'utf8')
  .replace('<script>', '<script>window.GCS_SAME=' + JSON.stringify(BASE + '/gcs-peer') + ';</script><script>');

app.set('trust proxy', true);
app.get([BASE + '/', BASE + '/index.html', BASE || '/'], (req, res) => {
  res.set('Cache-Control', 'no-store').type('html').send(html);
});
app.use(BASE + '/gcs-peer', ExpressPeerServer(server, { path: '/', proxied: true, allow_discovery: false }));
app.get(BASE + '/health', (req, res) => res.send('ok'));

server.listen(PORT, '0.0.0.0', () => console.log('Gridiron on http://0.0.0.0:' + PORT + (BASE || '/')));
