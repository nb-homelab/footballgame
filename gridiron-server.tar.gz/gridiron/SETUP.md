# Gridiron Call Sheet – server setup (instructions for Claude)

You are setting up a small Node app on this server. It serves a single-page football game
(`game.html`) and the matchmaking server that lets two players join each other with a 6-digit
code. Everything runs on ONE port. The game page automatically uses the same host for matchmaking,
so no extra config is needed in the browser.

Files in this folder: `server.js`, `package.json`, `game.html`, `SETUP.md`.

## 1. Install and run
```
cd <this folder>
npm install            # installs express + peer
PORT=3100 node server.js
curl localhost:3100/health      # -> ok
```
Pick any free port (default 3100). Keep it running with the server's existing method
(systemd, pm2, docker, etc.). Example systemd unit (adjust paths/user):
```
[Unit]
Description=Gridiron Call Sheet
After=network.target
[Service]
WorkingDirectory=/FULL/PATH/gridiron
Environment=PORT=3100
ExecStart=/usr/bin/node server.js
Restart=always
User=www-data
[Install]
WantedBy=multi-user.target
```

## 2. Put it behind the website (serve it over HTTPS)
The reverse proxy MUST forward WebSockets and the `/gcs-peer` path. Pick what matches the
existing web server.

### nginx (own subdomain, e.g. football.example.com)
```
location / {
    proxy_pass http://127.0.0.1:3100;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 3600s;
}
```
### nginx (sub-path, e.g. example.com/football/)
Start the app with `BASE_PATH=/football` and add `location /football/ { ...same proxy settings... }`
(keep the `/football/` prefix: `proxy_pass http://127.0.0.1:3100;` with NO trailing path).

### Apache
Enable `mod_proxy mod_proxy_http mod_proxy_wstunnel mod_rewrite`, then:
```
RewriteEngine On
RewriteCond %{HTTP:Upgrade} =websocket [NC]
RewriteRule ^/(.*)$ ws://127.0.0.1:3100/$1 [P,L]
ProxyPass / http://127.0.0.1:3100/
ProxyPassReverse / http://127.0.0.1:3100/
```
(Same idea with a `/football/` prefix if sub-pathed and `BASE_PATH=/football`.)

### Caddy
```
football.example.com {
    reverse_proxy 127.0.0.1:3100
}
```

## 3. Verify
- Open the site URL in two browser windows. In one click "Create game" – a 6-digit code appears.
  In the other type the code and click "Join". Both should show connected.
- If it fails: `curl https://YOUR-SITE/gcs-peer/` should return JSON starting with
  `{"name":"PeerJS Server"`; that proves the proxy forwards the path. Make sure WebSocket upgrade
  headers pass through and that the site is served over HTTPS (browsers block insecure
  WebSockets on HTTPS pages).
- Only 80/443 need to be open to the internet; the app's own port can stay local.

Nothing else is needed: no database, no accounts, no secrets. Game traffic between the two
players is peer-to-peer; this server only introduces them.
